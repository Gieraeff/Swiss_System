from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set


@dataclass
class Team:
    id: int
    name: str
    seed: int
    swiss_points: int = 0
    cups_metric: int = 0
    swiss_games_played: int = 0
    opponents: Set[int] = field(default_factory=set)
    last_finish_ts: float = 0.0
    active_match_id: Optional[str] = None
    ko_seed: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "seed": self.seed,
            "swiss_points": self.swiss_points,
            "cups_metric": self.cups_metric,
            "swiss_games_played": self.swiss_games_played,
            "opponents": sorted(self.opponents),
            "last_finish_ts": self.last_finish_ts,
            "active_match_id": self.active_match_id,
            "ko_seed": self.ko_seed,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Team":
        return cls(
            id=int(data["id"]),
            name=str(data["name"]),
            seed=int(data["seed"]),
            swiss_points=int(data.get("swiss_points", 0)),
            cups_metric=int(data.get("cups_metric", 0)),
            swiss_games_played=int(data.get("swiss_games_played", 0)),
            opponents={int(x) for x in data.get("opponents", [])},
            last_finish_ts=float(data.get("last_finish_ts", 0.0)),
            active_match_id=data.get("active_match_id"),
            ko_seed=(int(data["ko_seed"]) if data.get("ko_seed") is not None else None),
        )


@dataclass
class Match:
    match_id: str
    phase: str
    table: Optional[int]
    team_a: int
    team_b: int
    wave_index: Optional[int] = None
    wave_order: Optional[int] = None
    status: str = "pending"  # pending / active / finished
    winner: Optional[int] = None
    loser: Optional[int] = None
    is_overtime: bool = False
    loser_cups_hit: Optional[int] = None
    started_ts: float = 0.0
    ended_ts: Optional[float] = None
    point_cap_used: int = 0
    game_cap_used: int = 1
    slot_label: str = ""
    is_placeholder: bool = False
    placeholder_a: str = ""
    placeholder_b: str = ""
    resolved_a: Optional[int] = None
    resolved_b: Optional[int] = None
    source_match_id_a: Optional[str] = None
    source_match_id_b: Optional[str] = None
    source_outcome_a: Optional[str] = None
    source_outcome_b: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "match_id": self.match_id,
            "phase": self.phase,
            "table": self.table,
            "team_a": self.team_a,
            "team_b": self.team_b,
            "wave_index": self.wave_index,
            "wave_order": self.wave_order,
            "status": self.status,
            "winner": self.winner,
            "loser": self.loser,
            "is_overtime": self.is_overtime,
            "loser_cups_hit": self.loser_cups_hit,
            "started_ts": self.started_ts,
            "ended_ts": self.ended_ts,
            "point_cap_used": self.point_cap_used,
            "game_cap_used": self.game_cap_used,
            "slot_label": self.slot_label,
            "is_placeholder": self.is_placeholder,
            "placeholder_a": self.placeholder_a,
            "placeholder_b": self.placeholder_b,
            "resolved_a": self.resolved_a,
            "resolved_b": self.resolved_b,
            "source_match_id_a": self.source_match_id_a,
            "source_match_id_b": self.source_match_id_b,
            "source_outcome_a": self.source_outcome_a,
            "source_outcome_b": self.source_outcome_b,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Match":
        return cls(
            match_id=str(data["match_id"]),
            phase=str(data["phase"]),
            table=(int(data["table"]) if data.get("table") is not None else None),
            team_a=int(data["team_a"]),
            team_b=int(data["team_b"]),
            wave_index=(int(data["wave_index"]) if data.get("wave_index") is not None else None),
            wave_order=(int(data["wave_order"]) if data.get("wave_order") is not None else None),
            status=str(data.get("status", "pending")),
            winner=(int(data["winner"]) if data.get("winner") is not None else None),
            loser=(int(data["loser"]) if data.get("loser") is not None else None),
            is_overtime=bool(data.get("is_overtime", False)),
            loser_cups_hit=(int(data["loser_cups_hit"]) if data.get("loser_cups_hit") is not None else None),
            started_ts=float(data.get("started_ts", 0.0)),
            ended_ts=(float(data["ended_ts"]) if data.get("ended_ts") is not None else None),
            point_cap_used=int(data.get("point_cap_used", 0)),
            game_cap_used=int(data.get("game_cap_used", 1)),
            slot_label=str(data.get("slot_label", "")),
            is_placeholder=bool(data.get("is_placeholder", False)),
            placeholder_a=str(data.get("placeholder_a", "")),
            placeholder_b=str(data.get("placeholder_b", "")),
            resolved_a=(int(data["resolved_a"]) if data.get("resolved_a") is not None else None),
            resolved_b=(int(data["resolved_b"]) if data.get("resolved_b") is not None else None),
            source_match_id_a=data.get("source_match_id_a"),
            source_match_id_b=data.get("source_match_id_b"),
            source_outcome_a=data.get("source_outcome_a"),
            source_outcome_b=data.get("source_outcome_b"),
        )


@dataclass
class KOSlot:
    slot_id: str
    stage: str
    label: str
    team_a: Optional[int] = None
    team_b: Optional[int] = None
    status: str = "pending"
    winner: Optional[int] = None
    loser: Optional[int] = None
    match_id: Optional[str] = None
    table: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "slot_id": self.slot_id,
            "stage": self.stage,
            "label": self.label,
            "team_a": self.team_a,
            "team_b": self.team_b,
            "status": self.status,
            "winner": self.winner,
            "loser": self.loser,
            "match_id": self.match_id,
            "table": self.table,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "KOSlot":
        return cls(
            slot_id=str(data["slot_id"]),
            stage=str(data["stage"]),
            label=str(data["label"]),
            team_a=(int(data["team_a"]) if data.get("team_a") is not None else None),
            team_b=(int(data["team_b"]) if data.get("team_b") is not None else None),
            status=str(data.get("status", "pending")),
            winner=(int(data["winner"]) if data.get("winner") is not None else None),
            loser=(int(data["loser"]) if data.get("loser") is not None else None),
            match_id=data.get("match_id"),
            table=(int(data["table"]) if data.get("table") is not None else None),
        )


@dataclass
class WavePlan:
    wave_index: int
    match_ids: List[str] = field(default_factory=list)
    created_ts: float = 0.0
    status: str = "planned"  # planned / active / finished

    def to_dict(self) -> dict:
        return {
            "wave_index": self.wave_index,
            "match_ids": list(self.match_ids),
            "created_ts": self.created_ts,
            "status": self.status,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "WavePlan":
        return cls(
            wave_index=int(data["wave_index"]),
            match_ids=[str(x) for x in data.get("match_ids", [])],
            created_ts=float(data.get("created_ts", 0.0)),
            status=str(data.get("status", "planned")),
        )


@dataclass
class BGroupTeam:
    id: int
    name: str
    seed: int
    points: int = 0
    cups_metric: int = 0
    wins: int = 0
    losses: int = 0
    games_played: int = 0

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "seed": self.seed,
            "points": self.points,
            "cups_metric": self.cups_metric,
            "wins": self.wins,
            "losses": self.losses,
            "games_played": self.games_played,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "BGroupTeam":
        return cls(
            id=int(data["id"]),
            name=str(data["name"]),
            seed=int(data["seed"]),
            points=int(data.get("points", 0)),
            cups_metric=int(data.get("cups_metric", 0)),
            wins=int(data.get("wins", 0)),
            losses=int(data.get("losses", 0)),
            games_played=int(data.get("games_played", 0)),
        )


@dataclass
class BGroupMatch:
    match_id: str
    stage: str
    label: str
    team_a: int
    team_b: int
    table_label: str = "Tisch 5"
    status: str = "pending"
    winner: Optional[int] = None
    loser: Optional[int] = None
    points_a: Optional[int] = None
    points_b: Optional[int] = None
    loser_cups_hit: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "match_id": self.match_id,
            "stage": self.stage,
            "label": self.label,
            "team_a": self.team_a,
            "team_b": self.team_b,
            "table_label": self.table_label,
            "status": self.status,
            "winner": self.winner,
            "loser": self.loser,
            "points_a": self.points_a,
            "points_b": self.points_b,
            "loser_cups_hit": self.loser_cups_hit,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "BGroupMatch":
        return cls(
            match_id=str(data["match_id"]),
            stage=str(data["stage"]),
            label=str(data["label"]),
            team_a=int(data["team_a"]),
            team_b=int(data["team_b"]),
            table_label=str(data.get("table_label", "Tisch 5")),
            status=str(data.get("status", "pending")),
            winner=(int(data["winner"]) if data.get("winner") is not None else None),
            loser=(int(data["loser"]) if data.get("loser") is not None else None),
            points_a=(int(data["points_a"]) if data.get("points_a") is not None else None),
            points_b=(int(data["points_b"]) if data.get("points_b") is not None else None),
            loser_cups_hit=(int(data["loser_cups_hit"]) if data.get("loser_cups_hit") is not None else None),
        )


@dataclass
class BGroupState:
    phase: str = "SETUP"
    match_counter: int = 1
    teams: Dict[int, BGroupTeam] = field(default_factory=dict)
    matches: Dict[str, BGroupMatch] = field(default_factory=dict)
    podium: List[int] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "phase": self.phase,
            "match_counter": self.match_counter,
            "teams": [team.to_dict() for team in self.teams.values()],
            "matches": {match_id: match.to_dict() for match_id, match in self.matches.items()},
            "podium": list(self.podium),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "BGroupState":
        state = cls()
        state.phase = str(data.get("phase", "SETUP"))
        state.match_counter = int(data.get("match_counter", 1))
        state.teams = {int(team_data["id"]): BGroupTeam.from_dict(team_data) for team_data in data.get("teams", [])}
        state.matches = {str(match_id): BGroupMatch.from_dict(match_data) for match_id, match_data in data.get("matches", {}).items()}
        state.podium = [int(x) for x in data.get("podium", [])]
        return state


@dataclass
class TournamentState:
    phase: str = "SETUP"
    started_at: float = 0.0
    match_counter: int = 1
    wave_index: int = 0
    teams: Dict[int, Team] = field(default_factory=dict)
    matches: Dict[str, Match] = field(default_factory=dict)
    active_tables: Dict[int, str] = field(default_factory=dict)
    completed_match_ids: List[str] = field(default_factory=list)
    current_wave: Optional[WavePlan] = None
    prepared_wave: Optional[WavePlan] = None
    ko_slots: Dict[str, KOSlot] = field(default_factory=dict)
    logs: List[str] = field(default_factory=list)
    podium: List[int] = field(default_factory=list)
    top4: List[int] = field(default_factory=list)
    b_group: BGroupState = field(default_factory=BGroupState)
    last_save_ts: float = 0.0
    last_save_label: str = ""
    autosave_count: int = 0

    def to_dict(self) -> dict:
        return {
            "phase": self.phase,
            "started_at": self.started_at,
            "match_counter": self.match_counter,
            "wave_index": self.wave_index,
            "teams": [team.to_dict() for team in self.teams.values()],
            "matches": {match_id: match.to_dict() for match_id, match in self.matches.items()},
            "active_tables": {str(table): match_id for table, match_id in self.active_tables.items()},
            "completed_match_ids": list(self.completed_match_ids),
            "current_wave": self.current_wave.to_dict() if self.current_wave else None,
            "prepared_wave": self.prepared_wave.to_dict() if self.prepared_wave else None,
            "ko_slots": {slot_id: slot.to_dict() for slot_id, slot in self.ko_slots.items()},
            "logs": list(self.logs),
            "podium": list(self.podium),
            "top4": list(self.top4),
            "b_group": self.b_group.to_dict(),
            "last_save_ts": self.last_save_ts,
            "last_save_label": self.last_save_label,
            "autosave_count": self.autosave_count,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "TournamentState":
        state = cls()
        state.phase = str(data.get("phase", "SETUP"))
        state.started_at = float(data.get("started_at", 0.0))
        state.match_counter = int(data.get("match_counter", 1))
        state.wave_index = int(data.get("wave_index", 0))
        state.teams = {int(team_data["id"]): Team.from_dict(team_data) for team_data in data.get("teams", [])}
        state.matches = {str(match_id): Match.from_dict(match_data) for match_id, match_data in data.get("matches", {}).items()}
        state.active_tables = {int(table): str(match_id) for table, match_id in data.get("active_tables", {}).items()}
        state.completed_match_ids = [str(x) for x in data.get("completed_match_ids", [])]
        state.current_wave = WavePlan.from_dict(data["current_wave"]) if data.get("current_wave") else None
        state.prepared_wave = WavePlan.from_dict(data["prepared_wave"]) if data.get("prepared_wave") else None
        state.ko_slots = {slot_id: KOSlot.from_dict(slot_data) for slot_id, slot_data in data.get("ko_slots", {}).items()}
        state.logs = [str(x) for x in data.get("logs", [])]
        state.podium = [int(x) for x in data.get("podium", [])]
        state.top4 = [int(x) for x in data.get("top4", [])]
        state.b_group = BGroupState.from_dict(data["b_group"]) if data.get("b_group") else BGroupState()
        state.last_save_ts = float(data.get("last_save_ts", 0.0))
        state.last_save_label = str(data.get("last_save_label", ""))
        state.autosave_count = int(data.get("autosave_count", 0))
        return state
